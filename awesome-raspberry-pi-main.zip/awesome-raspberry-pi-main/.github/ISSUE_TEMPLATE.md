- [ ] My issue is an issue and not a PR. For additions or modifications I will create a [pull 
request](https://github.com/thibmaek/awesome-raspberry-pi/pulls).
